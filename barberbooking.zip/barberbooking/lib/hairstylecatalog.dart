import 'package:flutter/material.dart';
import 'booking.dart'; // Import halaman Booking

class HairstyleCatalogPage extends StatelessWidget {
  final List<Map<String, String>> hairstyles = [
    {
      'title': 'Korean Perm',
      'description': 'Rambut bergelombang natural, bertekstur lembut, khas gaya korea.',
      'image': 'assets/korean_perm.jpg',
    },
    {
      'title': 'French Crop',
      'description': 'Potongan pendek dengan poni rata, rapi dan maskulin.',
      'image': 'assets/french_crop.jpg',
    },
    {
      'title': 'Texture Crop',
      'description': 'Rambut pendek bertekstur, simpel dan stylish.',
      'image': 'assets/texture_crop.jpg',
    },
    {
      'title': 'Undercut',
      'description': 'Samping tipis, atas panjang, fleksibel untuk berbagai gaya.',
      'image': 'assets/undercut.jpg',
    },
    {
      'title': 'Modern Mullet',
      'description': 'Depan pendek, belakang panjang, tampilan edgy modern.',
      'image': 'assets/modern_mullet.jpg',
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Hairstyle Catalog'),
        backgroundColor: Colors.grey,
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: GridView.builder(
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 3, // Tiga kolom
            crossAxisSpacing: 8.0,
            mainAxisSpacing: 8.0,
            childAspectRatio: 1 / 1, // Ukuran 1:1 (persegi)
          ),
          itemCount: hairstyles.length,
          itemBuilder: (context, index) {
            final hairstyle = hairstyles[index];

            return GestureDetector(
              onTap: () {
                // Navigasi ke halaman Booking dengan data hairstyle
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => BookingPage(
                      hairstyle: hairstyle, // Kirim data hairstyle ke halaman Booking
                    ),
                  ),
                );
              },
              child: Card(
                elevation: 3,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10.0),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Expanded(
                      child: ClipRRect(
                        borderRadius: BorderRadius.vertical(
                          top: Radius.circular(10.0),
                        ),
                        child: Image.asset(
                          hairstyle['image']!, // Gambar dari daftar hairstyle
                          fit: BoxFit.cover,
                          width: double.infinity,
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            hairstyle['title']!, // Judul dari hairstyle
                            style: TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.bold,
                              color: Colors.blue.shade800,
                            ),
                          ),
                          SizedBox(height: 5),
                          Text(
                            hairstyle['description']!, // Deskripsi dari hairstyle
                            style: TextStyle(
                              fontSize: 10,
                              color: Colors.black87,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
