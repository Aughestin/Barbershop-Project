import 'package:flutter/material.dart';
import 'bookingstatus.dart'; // Pastikan mengimpor file yang benar

class BookingPage extends StatefulWidget {
  final Map<String, String> hairstyle; // Data hairstyle yang diterima

  // Constructor dengan required parameter
  BookingPage({required this.hairstyle});

  @override
  _BookingPageState createState() => _BookingPageState();
}

class _BookingPageState extends State<BookingPage> {
  final TextEditingController nameController = TextEditingController();
  DateTime? selectedDate;
  TimeOfDay? selectedTime;

  // Fungsi untuk memilih tanggal
  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: selectedDate ?? DateTime.now(),
      firstDate: DateTime(2000),
      lastDate: DateTime(2101),
    );
    if (picked != null && picked != selectedDate) {
      setState(() {
        selectedDate = picked;
      });
    }
  }

  // Fungsi untuk memilih waktu
  Future<void> _selectTime(BuildContext context) async {
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: selectedTime ?? TimeOfDay.now(),
    );
    if (picked != null && picked != selectedTime) {
      setState(() {
        selectedTime = picked;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Booking'),
        backgroundColor: Colors.grey,
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Gambar di sebelah kiri
            Expanded(
              flex: 2,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(10),
                child: Image.asset(
                  widget.hairstyle['image']!,
                  height: 200,
                  fit: BoxFit.contain, // Menjaga gambar agar tidak terpotong
                ),
              ),
            ),
            SizedBox(width: 16), // Memberikan ruang antar gambar dan form

            // Form booking di sebelah kanan
            Expanded(
              flex: 3,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    widget.hairstyle['title']!,
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: Colors.blue.shade800,
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    widget.hairstyle['description']!,
                    style: TextStyle(
                      fontSize: 14,
                      color: Colors.black87,
                    ),
                  ),
                  SizedBox(height: 40),

                  // Formulir untuk pengisian Nama
                  TextFormField(
                    controller: nameController,
                    decoration: InputDecoration(
                      labelText: 'Full Name',
                      prefixIcon: Icon(Icons.person),
                      border: OutlineInputBorder(),
                    ),
                  ),
                  SizedBox(height: 20),

                  // Menampilkan input tanggal
                  GestureDetector(
                    onTap: () => _selectDate(context),
                    child: TextFormField(
                      enabled: false, // Menonaktifkan input secara manual
                      decoration: InputDecoration(
                        labelText: selectedDate == null
                            ? 'Select Date'
                            : '${selectedDate!.day}/${selectedDate!.month}/${selectedDate!.year}',
                        prefixIcon: Icon(Icons.calendar_today),
                        border: OutlineInputBorder(),
                      ),
                    ),
                  ),
                  SizedBox(height: 20),

                  // Menampilkan input waktu
                  GestureDetector(
                    onTap: () => _selectTime(context),
                    child: TextFormField(
                      enabled: false, // Menonaktifkan input secara manual
                      decoration: InputDecoration(
                        labelText: selectedTime == null
                            ? 'Select Time'
                            : '${selectedTime!.hour}:${selectedTime!.minute}',
                        prefixIcon: Icon(Icons.access_time),
                        border: OutlineInputBorder(),
                      ),
                    ),
                  ),
                  SizedBox(height: 40),

                  // Tombol untuk booking
                  ElevatedButton(
                    onPressed: () {
                      if (nameController.text.isEmpty ||
                          selectedDate == null ||
                          selectedTime == null) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(content: Text("Please fill all fields!")),

                        );
                      } else {
                        bool isSuccess = true; // Tentukan jika tanggal adalah hari Minggu

                        // Memeriksa apakah tanggal booking adalah hari Minggu
                        if (selectedDate?.weekday == DateTime.sunday) {
                          isSuccess = false;
                        }

                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => BookingStatusPage(
                              isSuccess: isSuccess,
                              name: nameController.text,
                              dateTime:
                                  '${selectedDate!.day}/${selectedDate!.month}/${selectedDate!.year} ${selectedTime!.hour}:${selectedTime!.minute}',
                              contact: 'Contact Information',
                            ),
                          ),
                        );
                      }
                    },
                    child: Text('Book Appointment'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.blue.shade800,
                      padding: EdgeInsets.symmetric(horizontal: 40, vertical: 15),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
