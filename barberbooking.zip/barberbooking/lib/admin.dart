import 'package:flutter/material.dart';

class AdminPage extends StatefulWidget {
  @override
  _AdminPageState createState() => _AdminPageState();
}

class _AdminPageState extends State<AdminPage> {
  // Simulasi data booking
  List<Map<String, dynamic>> bookings = [
    {
      'name': 'John Doe',
      'dateTime': '2025-01-20 14:00',
      'contact': '1234567890',
      'status': 'Pending',
    },
    {
      'name': 'Jane Smith',
      'dateTime': '2025-01-21 10:30',
      'contact': '0987654321',
      'status': 'Pending',
    },
  ];

  // Daftar hairstyle
  List<String> hairstyles = [
    'Korean Perm',
    'French Crop',
    'Texture Crop',
    'Undercut',
    'Modern Mullet',
  ];

  // Fungsi untuk menampilkan dialog penolakan
  void _showRejectionDialog(Map<String, dynamic> booking) {
    final TextEditingController reasonController = TextEditingController();

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Reject Booking'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('Please provide a reason for rejecting this booking:'),
            SizedBox(height: 10),
            TextField(
              controller: reasonController,
              decoration: InputDecoration(
                labelText: 'Rejection Reason',
                border: OutlineInputBorder(),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              if (reasonController.text.isNotEmpty) {
                setState(() {
                  booking['status'] = 'Rejected';
                  booking['reason'] = reasonController.text;
                });
                Navigator.pop(context);
              } else {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Please provide a reason!')),
                );
              }
            },
            child: Text('Reject'),
          ),
        ],
      ),
    );
  }

  // Fungsi untuk menampilkan dialog konfirmasi
  void _showConfirmationDialog(Map<String, dynamic> booking) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Confirm Booking'),
        content: Text(
            'Are you sure you want to confirm the booking for ${booking['name']}?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              setState(() {
                booking['status'] = 'Confirmed';
              });
              Navigator.pop(context);
            },
            child: Text('Confirm'),
          ),
        ],
      ),
    );
  }

  // Fungsi untuk menambah hairstyle
  void _addHairstyle() {
    final TextEditingController hairstyleController = TextEditingController();

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Add New Hairstyle'),
        content: TextField(
          controller: hairstyleController,
          decoration: InputDecoration(
            labelText: 'Hairstyle Name',
            border: OutlineInputBorder(),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              if (hairstyleController.text.isNotEmpty) {
                setState(() {
                  hairstyles.add(hairstyleController.text);
                });
                Navigator.pop(context);
              } else {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Please enter a hairstyle name!')),
                );
              }
            },
            child: Text('Add'),
          ),
        ],
      ),
    );
  }

  // Fungsi untuk menghapus hairstyle
  void _deleteHairstyle(String hairstyle) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Delete Hairstyle'),
        content: Text('Are you sure you want to delete $hairstyle?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              setState(() {
                hairstyles.remove(hairstyle);
              });
              Navigator.pop(context);
            },
            child: Text('Delete'),
          ),
        ],
      ),
    );
  }

  // Fungsi untuk mengedit hairstyle
  void _editHairstyle(String oldHairstyle) {
    final TextEditingController hairstyleController =
        TextEditingController(text: oldHairstyle);

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Edit Hairstyle'),
        content: TextField(
          controller: hairstyleController,
          decoration: InputDecoration(
            labelText: 'Hairstyle Name',
            border: OutlineInputBorder(),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              if (hairstyleController.text.isNotEmpty) {
                setState(() {
                  int index = hairstyles.indexOf(oldHairstyle);
                  hairstyles[index] = hairstyleController.text;
                });
                Navigator.pop(context);
              } else {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Please enter a hairstyle name!')),
                );
              }
            },
            child: Text('Save'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Admin Panel'),
        backgroundColor: Colors.brown,
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            // Booking Management Section
            Expanded(
              child: ListView(
                children: [
                  // Bagian Data Booking
                  Text(
                    'Booking Data',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: Colors.brown,
                    ),
                  ),
                  SizedBox(height: 10),
                  ...bookings.map((booking) {
                    return Card(
                      margin: EdgeInsets.symmetric(vertical: 5),
                      child: ListTile(
                        title: Text(booking['name']),
                        subtitle: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('Date & Time: ${booking['dateTime']}'),
                            Text('Contact: ${booking['contact']}'),
                            Text(
                              'Status: ${booking['status']}',
                              style: TextStyle(
                                color: booking['status'] == 'Confirmed'
                                    ? Colors.green
                                    : booking['status'] == 'Rejected'
                                        ? Colors.red
                                        : Colors.orange,
                              ),
                            ),
                            if (booking['status'] == 'Rejected' &&
                                booking.containsKey('reason'))
                              Text('Reason: ${booking['reason']}'),
                          ],
                        ),
                        trailing: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            if (booking['status'] == 'Pending')
                              IconButton(
                                icon: Icon(Icons.check_circle, color: Colors.green),
                                onPressed: () =>
                                    _showConfirmationDialog(booking),
                              ),
                            if (booking['status'] == 'Pending')
                              IconButton(
                                icon: Icon(Icons.cancel, color: Colors.red),
                                onPressed: () => _showRejectionDialog(booking),
                              ),
                          ],
                        ),
                      ),
                    );
                  }).toList(),
                ],
              ),
            ),
            Divider(),
            // Hairstyle Management Section
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text(
                'Manage Hairstyle Catalog',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Colors.brown,
                ),
              ),
            ),
            Expanded(
              child: ListView(
                children: hairstyles.map((hairstyle) {
                  return ListTile(
                    title: Text(hairstyle),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        IconButton(
                          icon: Icon(Icons.edit),
                          onPressed: () => _editHairstyle(hairstyle),
                        ),
                        IconButton(
                          icon: Icon(Icons.delete, color: Colors.red),
                          onPressed: () => _deleteHairstyle(hairstyle),
                        ),
                      ],
                    ),
                  );
                }).toList(),
              ),
            ),
            ElevatedButton(
              onPressed: _addHairstyle,
              child: Text('Add New Hairstyle'),
            ),
          ],
        ),
      ),
    );
  }
}
