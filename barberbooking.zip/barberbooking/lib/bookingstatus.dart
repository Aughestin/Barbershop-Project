import 'package:flutter/material.dart';
import 'reschedule.dart'; // Import halaman Reschedule
import 'bookingdetail.dart'; // Import halaman BookingDetail

class BookingStatusPage extends StatelessWidget {
  final bool isSuccess; // Status keberhasilan booking
  final String name; // Nama pelanggan
  final String dateTime; // Tanggal dan waktu booking
  final String contact; // Kontak pelanggan

  BookingStatusPage({
    required this.isSuccess,
    required this.name,
    required this.dateTime,
    required this.contact,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Booking Status'),
        backgroundColor: Colors.blue.shade800,
        centerTitle: true,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Ikon status booking
            Icon(
              isSuccess ? Icons.check_circle : Icons.cancel,
              size: 80,
              color: isSuccess ? Colors.green : Colors.red,
            ),
            SizedBox(height: 20),

            // Pesan status booking
            Text(
              isSuccess
                  ? 'Booking Successful!'
                  : 'Booking Failed. Scheduling is unavailable on Sundays.',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 20),

            // Tombol tindakan
            ElevatedButton(
              onPressed: () {
                if (isSuccess) {
                  // Arahkan ke halaman detail booking jika sukses
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => BookingDetailPage(
                        name: name,
                        dateTime: dateTime,
                        contact: contact,
                      ),
                    ),
                  );
                } else {
                  // Arahkan ke halaman reschedule jika gagal
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => ReschedulePage(),
                    ),
                  );
                }
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: isSuccess ? Colors.green : Colors.red,
                padding: EdgeInsets.symmetric(horizontal: 40, vertical: 15),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
              child: Text(isSuccess ? 'View Booking Details' : 'Reschedule'),
            ),
          ],
        ),
      ),
    );
  }
}
